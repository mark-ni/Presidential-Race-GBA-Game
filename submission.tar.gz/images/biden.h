/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 biden biden.png 
 * Time-stamp: Monday 11/09/2020, 18:36:10
 * 
 * Image Information
 * -----------------
 * biden.png 22@28
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BIDEN_H
#define BIDEN_H

extern const unsigned short biden[616];
#define BIDEN_SIZE 1232
#define BIDEN_LENGTH 616
#define BIDEN_WIDTH 22
#define BIDEN_HEIGHT 28

#endif

