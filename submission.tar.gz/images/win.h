/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 win kanyeWinsResized.png 
 * Time-stamp: Monday 11/09/2020, 05:58:56
 * 
 * Image Information
 * -----------------
 * kanyeWinsResized.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WIN_H
#define WIN_H

extern const unsigned short kanyeWinsResized[38400];
#define KANYEWINSRESIZED_SIZE 76800
#define KANYEWINSRESIZED_LENGTH 38400
#define KANYEWINSRESIZED_WIDTH 240
#define KANYEWINSRESIZED_HEIGHT 160

#endif

