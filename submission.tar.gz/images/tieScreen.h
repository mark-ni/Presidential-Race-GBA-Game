/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 tieScreen tieScreen.png 
 * Time-stamp: Tuesday 11/10/2020, 00:06:24
 * 
 * Image Information
 * -----------------
 * tieScreen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TIESCREEN_H
#define TIESCREEN_H

extern const unsigned short tieScreen[38400];
#define TIESCREEN_SIZE 76800
#define TIESCREEN_LENGTH 38400
#define TIESCREEN_WIDTH 240
#define TIESCREEN_HEIGHT 160

#endif

