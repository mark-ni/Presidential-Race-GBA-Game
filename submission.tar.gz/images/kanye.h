/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 kanye kanye.png 
 * Time-stamp: Monday 11/09/2020, 05:57:56
 * 
 * Image Information
 * -----------------
 * kanye.png 17@33
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef KANYE_H
#define KANYE_H

extern const unsigned short kanye[561];
#define KANYE_SIZE 1122
#define KANYE_LENGTH 561
#define KANYE_WIDTH 17
#define KANYE_HEIGHT 33

#endif

