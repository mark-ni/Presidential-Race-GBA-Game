/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 embarrassedYe embarrassedYe.png 
 * Time-stamp: Monday 11/09/2020, 19:28:31
 * 
 * Image Information
 * -----------------
 * embarrassedYe.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef EMBARRASSEDYE_H
#define EMBARRASSEDYE_H

extern const unsigned short embarrassedYe[38400];
#define EMBARRASSEDYE_SIZE 76800
#define EMBARRASSEDYE_LENGTH 38400
#define EMBARRASSEDYE_WIDTH 240
#define EMBARRASSEDYE_HEIGHT 160

#endif

