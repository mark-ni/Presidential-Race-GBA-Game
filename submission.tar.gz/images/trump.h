/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 trump trump.png 
 * Time-stamp: Monday 11/09/2020, 18:32:23
 * 
 * Image Information
 * -----------------
 * trump.png 22@28
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TRUMP_H
#define TRUMP_H

extern const unsigned short trump[616];
#define TRUMP_SIZE 1232
#define TRUMP_LENGTH 616
#define TRUMP_WIDTH 22
#define TRUMP_HEIGHT 28

#endif

