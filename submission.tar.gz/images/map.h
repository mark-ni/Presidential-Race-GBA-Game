/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 map usmap.png 
 * Time-stamp: Monday 11/09/2020, 05:59:20
 * 
 * Image Information
 * -----------------
 * usmap.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MAP_H
#define MAP_H

extern const unsigned short usmap[38400];
#define USMAP_SIZE 76800
#define USMAP_LENGTH 38400
#define USMAP_WIDTH 240
#define USMAP_HEIGHT 160

#endif

