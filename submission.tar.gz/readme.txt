INSPIRATION: I saw a Kanye election meme and decided to
make a game around it (the title is the meme).

In this game you play as cool, calm, collected Kanye West
and are trying to earn more electoral votes than your angry,
shouting (?), rabid (???) competitors Joe Biden and Donald
Trump. Use the arrow keys to move around the states and
capture each vote before your competitors in this lifelike
simulation of the presidential election process! While
they're busy fighting each other, it's time for you -- yes
you, Kanye West, to swoop in to steal the presidency! But don't
be too slow, or you'll miss the big fish; your opponents
automatically adjust their paths based on which electoral
votes are remaining and where!

Also, electoral votes for each state are identical to their
values in real life, and their placements are identical to
where I think the capitol of each state is (in real life)!
How educational!!!
